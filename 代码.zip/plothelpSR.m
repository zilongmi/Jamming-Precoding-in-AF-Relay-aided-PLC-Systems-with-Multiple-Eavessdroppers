annotation('textarrow','String','y = x ');
annotation('ellipse');
ylabel('The average secrecy rate(bit/s/Hz)','FontSize',22);

xlabel('The number of iterations','FontSize',22);
%  xlabel('Power constraint','FontSize',22);
legend('FontSize',22);
set(gca,'FontSize',22);
set(gca,'DefaultMarkerSize',10);
gca.MarkerSize=20;