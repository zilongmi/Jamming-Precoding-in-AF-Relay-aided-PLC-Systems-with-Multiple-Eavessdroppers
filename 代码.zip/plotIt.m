tar=3;
It=zeros(maxy,1);
% ItSecrecy=zeros(number,index_max);
ItSecrecy={};
ItAverage={};
for y=1:1:number 
        ItSecrecy{y}=[];
end

for index=1:1:tar 
for t=1:1:number 
   for y=1:1:maxy
        if WorstCaseSecrecyRate(t,index,y)~=0 
            ItSecrecy{t}=[ItSecrecy{t},max(WorstCaseSecrecyRate(t,index,1:y))];
        end
 
   end
end
end
thisl=1;
for t=1:1:number 
    thisl=max(thisl,max(size(ItSecrecy{t})));
end

res=zeros(1,thisl);

    
    
for t=1:1:number 
   for x=1:1:thisl
       [p,maxlong]=size(ItSecrecy{t});
       if maxlong~=0 
       cur=ItSecrecy{t};
       res(x)=res(x)+cur(min(x,maxlong));
       end
   end
end


AA=res/number;