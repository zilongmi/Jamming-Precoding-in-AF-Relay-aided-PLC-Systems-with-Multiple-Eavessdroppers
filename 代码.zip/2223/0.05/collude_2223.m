   clc;clear;
load("Pathrecord");
k=1;%numbers of strings
Ns=2;%source antenna
Nr=2;%relay antenna
Nd=2;%destination antenna
Ne=3;%eve antenna
a=Ne*(4*Ne+10*k+2*Nr);
Sigma_ChannalErr = 0.05;


X=[eye(k),zeros(k,Nr-k)];
%%


WorstCaseSecrecyRate=zeros(number,index_max,maxy); 
countsum=zeros(1,index_max);


t=1;
while t<=number
    l=0;
    Y=[];%the objective value of each iteration

    

Hr1=Hr1p([1:2],[2*t+1:2*(t+1)]);
Hr1=Hr1(1:Nr,1:Ns);
Hes1=Hes1p([1:3],[2*t+1:2*(t+1)]);
Hes1=Hes1(1:Ne,1:Ns);
Her1=Her1p([1:3],[2*t+1:2*(t+1)]);
Her1=Her1(1:Ne,1:Nr);
Hes2=Hes2p([1:3],[2*t+1:2*(t+1)]);
Hes2=Hes2(1:Ne,1:Ns);
Her2=Her2p([1:3],[2*t+1:2*(t+1)]);
Her2=Her2(1:Ne,1:Nr);
Hd=Hdp([1:3],[2*t+1:2*(t+1)]);
Hd=Hd(1:Nd,1:Nr);
Hl=Hlp([1:2],[2*t+1:2*(t+1)]);
Hl=Hl(1:Nr,1:Nr);


sigd=sigdp([1:1],[t+1:(t+1)]);
sigr=sigrp([1:1],[t+1:(t+1)]);
sige=sigep([1:1],[t+1:(t+1)]);


Hrl_v=Sigma_ChannalErr*norm(Hr1);
Hl_v=Sigma_ChannalErr*norm(Hl);
Hes1_v=Sigma_ChannalErr*norm(Hes1);
Her1_v=Sigma_ChannalErr*norm(Her1);
Hes2_v=Sigma_ChannalErr*norm(Hes2);
Her2_v=Sigma_ChannalErr*norm(Her2);
Hd_v=Sigma_ChannalErr*norm(Hd);

Fd=eye(k,k);
Fe1=eye(k,k);
Fe2=eye(Nr,Nr);
Fe3=eye(2*Ne,2*Ne);
Fe31=eye(2*Ne,Ne);
Fe32=eye(2*Ne,Ne);

Dd=(eye(k,Nd)+i*eye(k,Nd))/sqrt(2) ;
De1=(eye(k,Ne)+i*eye(k,Ne))/sqrt(2) ;
De21=(eye(Nr,Ne)+i*eye(Nr,Ne))/sqrt(2);
De22=(eye(Nr,Ne)+i*eye(Nr,Ne))/sqrt(2) ;
De23=(eye(Nr,Ne)+i*eye(Nr,Ne))/sqrt(2);

W=(eye(Nr,k)+i*eye(Nr,k))/sqrt(2);
V=(eye(Nr,k)+i*eye(Nr,k))/sqrt(2);
A=(eye(Nr,k)+i*eye(Nr,k))/sqrt(2);
G=(eye(Nr,Nr)+i*eye(Nr,Nr))/sqrt(2);


cvx_status='';


for index=1:1:index_max
    PS=10^(((index-1)*interval+DBPtot_min)/10);
    PR=10^(((index-1)*interval+DBPtot_min)/10);
    count=0;

if strcmp(cvx_status,'Infeasible')

W=(eye(Nr,k)+i*eye(Nr,k))/sqrt(2);
V=(eye(Nr,k)+i*eye(Nr,k))/sqrt(2);
A=(eye(Nr,k)+i*eye(Nr,k))/sqrt(2);
G=(eye(Nr,Nr)+i*eye(Nr,Nr))/sqrt(2);


      end
this=-10000000;
last=-100000;
l=1;
while l<=maxy&& (abs(this-last)>=0.005)
    %% uppdate G
   if strcmp(cvx_status,'Infeasible')
      break;
   end


cvx_begin SDP  quiet
cvx_solver mosek

variable G(Nr,Nr) complex


variable betad;
variable lambdadr1 nonnegative
variable lambdadd nonnegative
variable lambdadl nonnegative
variable phid(2*k^2+k*(Nr+Nd),1) complex
variable omegardr1(2*k^2+k*(Nr+Nd),Nr*Ns) complex
variable omegardd(2*k^2+k*(Nr+Nd),Nr*Nd) complex
variable omegardl(2*k^2+k*(Nr+Nd),Nr^2) complex
variable Pdr1(Nr*Ns,2*k^2+k*(Nr+Nd)+1) complex
variable Pdd(Nr*Nd,2*k^2+k*(Nr+Nd)+1) complex
variable Pdl(Nr^2,2*k^2+k*(Nr+Nd)+1) complex
variable thetad(Nr*(Ns+Nd+Nr),2*k^2+k*(Nr+Nd)+1) complex

variable phie1(k^2+k*Ne,1) complex
variable  omegare1er1(k^2+k*Ne,Ne*Nr) complex
variable  Pe1er1(Ne*Nr,k^2+k*Ne+1) complex
variable  thetae1(Ne*Nr,k^2+k*Ne+1) complex
variable betae1
variable lambdae1 nonnegative

variable phie2(Nr^2+3*Nr*Ne,1) complex
variable  omegare2es2(Nr^2+3*Nr*Ne,Ne*Ns)  complex
variable omegare2er2(Nr^2+3*Nr*Ne,Ne*Nr) complex
variable omegare2l(Nr^2+3*Nr*Ne,Nr^2) complex
variable   Pe2es2(Ne*Ns,Nr^2+3*Nr*Ne+1)  complex
variable Pe2er2(Ne*Nr,Nr^2+3*Nr*Ne+1)  complex     
variable Pe2l(Nr^2,Nr^2+3*Nr*Ne+1) complex
variable  thetae2(Ne*Ns+Ne*Nr+Nr^2,Nr^2+3*Nr*Ne+1) complex
variable betae2
variable lambdae21 nonnegative
variable lambdae22 nonnegative
variable lambdae23 nonnegative

variable phie3(a,1) complex
variable  omegare3er1(a,Ne*Nr)  complex
variable omegare3er2(a,Ne*Nr)  complex
variable omegare3es1(a,Ne*Ns)  complex
variable omegare3es2(a,Ne*Ns)  complex
variable omegare3l(a,Nr*Nr)  complex
variable omegare3r1(a,Ns*Nr) complex
variable  Pe3er1(Ne*Nr,a+1)  complex
variable Pe3er2(Ne*Nr,a+1)  complex
variable Pe3es1(Ne*Ns,a+1) complex
variable Pe3es2(Ne*Ns,a+1) complex
variable Pe3l(Nr*Nr,a+1) complex
variable Pe3r1(Ns*Nr,a+1) complex
variable  thetae3(Ne*(2*Nr+2*Ns)+Nr*(Nr+Ns),a+1) complex
variable betae3
variable lambdae31 nonnegative
variable lambdae32 nonnegative
variable lambdae33 nonnegative
variable lambdae34 nonnegative
variable lambdae35 nonnegative
variable lambdae36 nonnegative

% 
variable phip(2*Nr*k+Nr^2,1) complex
variable  omegarpr1(2*Nr*k+Nr^2,Nr*Ns)  complex
variable omegarpl(2*Nr*k+Nr^2,Nr^2) complex
variable  Ppr1(Nr*Ns,2*Nr*k+Nr^2+1)  complex
variable Ppl(Nr^2,2*Nr*k+Nr^2+1) complex
variable thetap(Nr*Ns+Nr^2,2*Nr*k+Nr^2+1) complex
variable lambdap1 nonnegative
variable lambdap2 nonnegative


maximize(2*k+Nr+2*Ne+2*log_det(Fd)+2*log_det(Fe1)+2*log_det(Fe2)+2*log_det(Fe3)...
    -betad-betae1-betae2-betae3)


subject to
%d
phid==[vec(Fd*(Dd*Hd*G*Hr1*W-eye(k)))',vec(Fd*Dd*Hd*G*Hl*V)',vec(sigr*Fd*Dd*Hd*G)',...
vec(sigd*Fd*Dd)']'
omegardr1==[kron(W.',Fd*Dd*Hd*G)',zeros(k^2+k*(Nr+Nd),Nr*Ns)']'
omegardd==[kron((G*Hr1*W).',Fd*Dd)',kron((G*Hl*V).',Fd*Dd)',kron(G.',sigr*Fd*Dd)',zeros(k*Nd,Nr*Nd)']'
omegardl==[zeros(k^2,Nr^2)',kron(V.',Fd*Dd*Hd*G)',zeros(k*(Nr+Nd),Nr^2)']'
Pdr1==[zeros(Nr*Ns,1),omegardr1']
Pdd==[zeros(Nr*Nd,1),omegardd']
Pdl==[zeros(Nr^2,1),omegardl']
thetad==-[Hrl_v*Pdr1',Hd_v*Pdd',Hl_v*Pdl']'
[[betad-(lambdadr1+lambdadd+lambdadl),phid';phid,eye(2*k^2+k*(Nr+Nd))],thetad';...
    thetad,blkdiag(lambdadr1*eye(Nr*Ns),lambdadd*eye(Nr*Nd),lambdadl*eye(Nr^2))]>=0

%e1
phie1==[vec(Fe1*(De1*Her1*V-eye(k)))',vec(sige*Fe1*De1)']'
omegare1er1==[kron(V.',Fe1*De1)',zeros(k*Ne,Ne*Nr)']'
Pe1er1==[zeros(Ne*Nr,1),omegare1er1']
thetae1==-Her1_v*Pe1er1
[[betae1-lambdae1,phie1';phie1,eye(k^2+k*Ne)],thetae1';thetae1,lambdae1*eye(Ne*Nr)]>=0

%e2
phie2==[vec(Fe2*(De21*Hes2*A*X+De22*Her2*G*Hl*V*X+sigr*De23*Her2*G-eye(Nr)))',...
    vec(sige*Fe2*De21)',vec(sige*Fe2*De22)',vec(sige*Fe2*De23)']'
omegare2es2==[kron((A*X).',Fe2*De21)',zeros(3*Nr*Ne,Ne*Ns)']'
omegare2er2==[kron((G*Hl*V*X).',Fe2*De22)'+kron(G.',sigr*Fe2*De23)',zeros(3*Nr*Ne,Ne*Nr)']'
omegare2l==[kron((V*X).',Fe2*De22*Her2*G)',zeros(3*Nr*Ne,Nr^2)']'
Pe2es2==[zeros(Ne*Ns,1),omegare2es2']
Pe2er2==[zeros(Ne*Ns,1),omegare2er2']
Pe2l==[zeros(Nr^2,1),omegare2l']
thetae2==-[Hes2_v*Pe2es2',Her2_v*Pe2er2',Hl_v*Pe2l']'
[[betae2-(lambdae21+lambdae22+lambdae23),phie2';phie2,eye(Nr^2+3*Nr*Ne)],thetae2';thetae2,...
    blkdiag(lambdae21*eye(Ne*Ns),lambdae22*eye(Nr*Ne),lambdae23*eye(Nr^2))]>=0

%e3
phie3==[vec(Fe31)',vec(Fe32)',vec((sige^-1)*Fe31*Her1*V)',vec((sige^-1)*Fe32*Hes2*A)',...
    vec((sige^-1)*Fe32*Her2*G*Hl*V)',vec((sige^-1)*sigr*Fe32*Her2*G)',vec((sige^-1)*Fe31*Hes1*W)',...
    vec((sige^-1)*Fe32*Her2*G*Hr1*W)']'
omegare3er1==[zeros(4*Ne^2,Ne*Nr)',kron(V.',(sige^-1)*Fe31)',zeros(a-4*Ne^2-2*Ne*k,Ne*Nr)']'
omegare3er2==[zeros(4*Ne^2+4*Ne*k,Ne*Nr)',kron((G*Hl*V).',(sige^-1)*Fe32)',...
    kron(G.',(sige^-1)*sigr*Fe32)',zeros(2*Ne*k,Ne*Nr)',kron((G*Hr1*W).',(sige^-1)*Fe32)']'    
omegare3es1==[zeros(a-4*Ne*k,Ne*Ns)',kron(W.',(sige^-1)*Fe31)',zeros(2*Ne*k,Ne*Ns)']'     
omegare3es2==[zeros(4*Ne^2+2*Ne*k,Ne*Ns)',kron(A.',(sige^-1)*Fe32)',zeros(2*Ne*(3*k+Nr),Ne*Ns)']'      
omegare3l==[zeros(4*Ne^2+4*Ne*k,Nr*Nr)',kron(V.',(sige^-1)*Fe32*Her2*G)',zeros(2*Ne*(Nr+2*k),Nr*Nr)']'    
omegare3r1==[zeros(a-2*Ne*k,Ns*Nr)',kron(W.',(sige^-1)*Fe32*Her2*G)']'       
Pe3er1==[zeros(Ne*Nr,1),omegare3er1']
Pe3er2==[zeros(Ne*Nr,1),omegare3er2']
Pe3es1==[zeros(Ne*Ns,1),omegare3es1']
Pe3es2==[zeros(Ne*Ns,1),omegare3es2']
Pe3l==[zeros(Nr*Nr,1),omegare3l']
Pe3r1==[zeros(Ns*Nr,1),omegare3r1']
thetae3==-[Her1_v*Pe3er1',Her2_v*Pe3er2',Hes1_v*Pe3es1',Hes2_v*Pe3es2',Hl_v*Pe3l',Hrl_v*Pe3r1']'
[[betae3-(lambdae31+lambdae32+lambdae33+lambdae34+lambdae35+lambdae36),phie3';phie3,eye(a)],thetae3';thetae3,...
  blkdiag(lambdae31*eye(Ne*Nr),lambdae32*eye(Ne*Nr),lambdae33*eye(Ne*Ns),lambdae34*eye(Ne*Ns),...
  lambdae35*eye(Nr*Nr),lambdae36*eye(Ns*Nr))]>=0
%p
 phip==[vec(G*Hr1*W)',vec(G*Hl*V)',vec(sigr*G)']'
 omegarpr1==[kron(W.',G)',zeros(Nr*k+Nr^2,Nr*Ns)']'
 omegarpl==[zeros(Nr*k,Nr^2)',kron(V.',G)',zeros(Nr^2,Nr^2)']'
 Ppr1==[zeros(Nr*Ns,1),omegarpr1'] 
 Ppl==[zeros(Nr^2,1),omegarpl']  
 thetap==-[Hrl_v*Ppr1',Hl_v*Ppl']'
   [[PR-(lambdap1+lambdap2),phip';phip,eye(2*Nr*k+Nr^2)],thetap';thetap,...
      blkdiag(lambdap1*eye(Nr*Ns),lambdap2*eye(Nr^2))]>=0
  
cvx_end
   
%% uppdate W,V,A
   if strcmp(cvx_status,'Infeasible')
      break;
   end


cvx_begin SDP  quiet
cvx_solver mosek

variable V(Nr,k) complex
variable W(Ns,k)  complex
variable A(Ns,k)  complex

variable betad;
variable lambdadr1 nonnegative
variable lambdadd nonnegative
variable lambdadl nonnegative
variable phid(2*k^2+k*(Nr+Nd),1) complex
variable omegardr1(2*k^2+k*(Nr+Nd),Nr*Ns) complex
variable omegardd(2*k^2+k*(Nr+Nd),Nr*Nd) complex
variable omegardl(2*k^2+k*(Nr+Nd),Nr^2) complex
variable Pdr1(Nr*Ns,2*k^2+k*(Nr+Nd)+1) complex
variable Pdd(Nr*Nd,2*k^2+k*(Nr+Nd)+1) complex
variable Pdl(Nr^2,2*k^2+k*(Nr+Nd)+1) complex
variable thetad(Nr*(Ns+Nd+Nr),2*k^2+k*(Nr+Nd)+1) complex

variable phie1(k^2+k*Ne,1) complex
variable  omegare1er1(k^2+k*Ne,Ne*Nr) complex
variable  Pe1er1(Ne*Nr,k^2+k*Ne+1) complex
variable  thetae1(Ne*Nr,k^2+k*Ne+1) complex
variable betae1
variable lambdae1 nonnegative

variable phie2(Nr^2+3*Nr*Ne,1) complex
variable  omegare2es2(Nr^2+3*Nr*Ne,Ne*Ns)  complex
variable omegare2er2(Nr^2+3*Nr*Ne,Ne*Nr) complex
variable omegare2l(Nr^2+3*Nr*Ne,Nr^2) complex
variable   Pe2es2(Ne*Ns,Nr^2+3*Nr*Ne+1)  complex
variable Pe2er2(Ne*Nr,Nr^2+3*Nr*Ne+1)  complex     
variable Pe2l(Nr^2,Nr^2+3*Nr*Ne+1) complex
variable  thetae2(Ne*Ns+Ne*Nr+Nr^2,Nr^2+3*Nr*Ne+1) complex
variable betae2
variable lambdae21 nonnegative
variable lambdae22 nonnegative
variable lambdae23 nonnegative

variable phie3(a,1) complex
variable  omegare3er1(a,Ne*Nr)  complex
variable omegare3er2(a,Ne*Nr)  complex
variable omegare3es1(a,Ne*Ns)  complex
variable omegare3es2(a,Ne*Ns)  complex
variable omegare3l(a,Nr*Nr)  complex
variable omegare3r1(a,Ns*Nr) complex
variable  Pe3er1(Ne*Nr,a+1)  complex
variable Pe3er2(Ne*Nr,a+1)  complex
variable Pe3es1(Ne*Ns,a+1) complex
variable Pe3es2(Ne*Ns,a+1) complex
variable Pe3l(Nr*Nr,a+1) complex
variable Pe3r1(Ns*Nr,a+1) complex
variable  thetae3(Ne*(2*Nr+2*Ns)+Nr*(Nr+Ns),a+1) complex
variable betae3
variable lambdae31 nonnegative
variable lambdae32 nonnegative
variable lambdae33 nonnegative
variable lambdae34 nonnegative
variable lambdae35 nonnegative
variable lambdae36 nonnegative

% 
variable phip(2*Nr*k+Nr^2,1) complex
variable  omegarpr1(2*Nr*k+Nr^2,Nr*Ns)  complex
variable omegarpl(2*Nr*k+Nr^2,Nr^2) complex
variable  Ppr1(Nr*Ns,2*Nr*k+Nr^2+1)  complex
variable Ppl(Nr^2,2*Nr*k+Nr^2+1) complex
variable thetap(Nr*Ns+Nr^2,2*Nr*k+Nr^2+1) complex
variable lambdap1 nonnegative
variable lambdap2 nonnegative


maximize(2*k+Nr+2*Ne+2*log_det(Fd)+2*log_det(Fe1)+2*log_det(Fe2)+2*log_det(Fe3)...
    -betad-betae1-betae2-betae3)


subject to
%d
phid==[vec(Fd*(Dd*Hd*G*Hr1*W-eye(k)))',vec(Fd*Dd*Hd*G*Hl*V)',vec(sigr*Fd*Dd*Hd*G)',...
vec(sigd*Fd*Dd)']'
omegardr1==[kron(W.',Fd*Dd*Hd*G)',zeros(k^2+k*(Nr+Nd),Nr*Ns)']'
omegardd==[kron((G*Hr1*W).',Fd*Dd)',kron((G*Hl*V).',Fd*Dd)',kron(G.',sigr*Fd*Dd)',zeros(k*Nd,Nr*Nd)']'
omegardl==[zeros(k^2,Nr^2)',kron(V.',Fd*Dd*Hd*G)',zeros(k*(Nr+Nd),Nr^2)']'
Pdr1==[zeros(Nr*Ns,1),omegardr1']
Pdd==[zeros(Nr*Nd,1),omegardd']
Pdl==[zeros(Nr^2,1),omegardl']
thetad==-[Hrl_v*Pdr1',Hd_v*Pdd',Hl_v*Pdl']'
[[betad-(lambdadr1+lambdadd+lambdadl),phid';phid,eye(2*k^2+k*(Nr+Nd))],thetad';...
    thetad,blkdiag(lambdadr1*eye(Nr*Ns),lambdadd*eye(Nr*Nd),lambdadl*eye(Nr^2))]>=0

%e1
phie1==[vec(Fe1*(De1*Her1*V-eye(k)))',vec(sige*Fe1*De1)']'
omegare1er1==[kron(V.',Fe1*De1)',zeros(k*Ne,Ne*Nr)']'
Pe1er1==[zeros(Ne*Nr,1),omegare1er1']
thetae1==-Her1_v*Pe1er1
[[betae1-lambdae1,phie1';phie1,eye(k^2+k*Ne)],thetae1';thetae1,lambdae1*eye(Ne*Nr)]>=0

%e2
phie2==[vec(Fe2*(De21*Hes2*A*X+De22*Her2*G*Hl*V*X+sigr*De23*Her2*G-eye(Nr)))',...
    vec(sige*Fe2*De21)',vec(sige*Fe2*De22)',vec(sige*Fe2*De23)']'
omegare2es2==[kron((A*X).',Fe2*De21)',zeros(3*Nr*Ne,Ne*Ns)']'
omegare2er2==[kron((G*Hl*V*X).',Fe2*De22)'+kron(G.',sigr*Fe2*De23)',zeros(3*Nr*Ne,Ne*Nr)']'
omegare2l==[kron((V*X).',Fe2*De22*Her2*G)',zeros(3*Nr*Ne,Nr^2)']'
Pe2es2==[zeros(Ne*Ns,1),omegare2es2']
Pe2er2==[zeros(Ne*Ns,1),omegare2er2']
Pe2l==[zeros(Nr^2,1),omegare2l']
thetae2==-[Hes2_v*Pe2es2',Her2_v*Pe2er2',Hl_v*Pe2l']'
[[betae2-(lambdae21+lambdae22+lambdae23),phie2';phie2,eye(Nr^2+3*Nr*Ne)],thetae2';thetae2,...
    blkdiag(lambdae21*eye(Ne*Ns),lambdae22*eye(Nr*Ne),lambdae23*eye(Nr^2))]>=0

%e3
phie3==[vec(Fe31)',vec(Fe32)',vec((sige^-1)*Fe31*Her1*V)',vec((sige^-1)*Fe32*Hes2*A)',...
    vec((sige^-1)*Fe32*Her2*G*Hl*V)',vec((sige^-1)*sigr*Fe32*Her2*G)',vec((sige^-1)*Fe31*Hes1*W)',...
    vec((sige^-1)*Fe32*Her2*G*Hr1*W)']'
omegare3er1==[zeros(4*Ne^2,Ne*Nr)',kron(V.',(sige^-1)*Fe31)',zeros(a-4*Ne^2-2*Ne*k,Ne*Nr)']'
omegare3er2==[zeros(4*Ne^2+4*Ne*k,Ne*Nr)',kron((G*Hl*V).',(sige^-1)*Fe32)',...
    kron(G.',(sige^-1)*sigr*Fe32)',zeros(2*Ne*k,Ne*Nr)',kron((G*Hr1*W).',(sige^-1)*Fe32)']'    
omegare3es1==[zeros(a-4*Ne*k,Ne*Ns)',kron(W.',(sige^-1)*Fe31)',zeros(2*Ne*k,Ne*Ns)']'     
omegare3es2==[zeros(4*Ne^2+2*Ne*k,Ne*Ns)',kron(A.',(sige^-1)*Fe32)',zeros(2*Ne*(3*k+Nr),Ne*Ns)']'      
omegare3l==[zeros(4*Ne^2+4*Ne*k,Nr*Nr)',kron(V.',(sige^-1)*Fe32*Her2*G)',zeros(2*Ne*(Nr+2*k),Nr*Nr)']'    
omegare3r1==[zeros(a-2*Ne*k,Ns*Nr)',kron(W.',(sige^-1)*Fe32*Her2*G)']'       
Pe3er1==[zeros(Ne*Nr,1),omegare3er1']
Pe3er2==[zeros(Ne*Nr,1),omegare3er2']
Pe3es1==[zeros(Ne*Ns,1),omegare3es1']
Pe3es2==[zeros(Ne*Ns,1),omegare3es2']
Pe3l==[zeros(Nr*Nr,1),omegare3l']
Pe3r1==[zeros(Ns*Nr,1),omegare3r1']
thetae3==-[Her1_v*Pe3er1',Her2_v*Pe3er2',Hes1_v*Pe3es1',Hes2_v*Pe3es2',Hl_v*Pe3l',Hrl_v*Pe3r1']'
[[betae3-(lambdae31+lambdae32+lambdae33+lambdae34+lambdae35+lambdae36),phie3';phie3,eye(a)],thetae3';thetae3,...
  blkdiag(lambdae31*eye(Ne*Nr),lambdae32*eye(Ne*Nr),lambdae33*eye(Ne*Ns),lambdae34*eye(Ne*Ns),...
  lambdae35*eye(Nr*Nr),lambdae36*eye(Ns*Nr))]>=0
%p
 phip==[vec(G*Hr1*W)',vec(G*Hl*V)',vec(sigr*G)']'
 omegarpr1==[kron(W.',G)',zeros(Nr*k+Nr^2,Nr*Ns)']'
 omegarpl==[zeros(Nr*k,Nr^2)',kron(V.',G)',zeros(Nr^2,Nr^2)']'
 Ppr1==[zeros(Nr*Ns,1),omegarpr1'] 
 Ppl==[zeros(Nr^2,1),omegarpl']  
 thetap==-[Hrl_v*Ppr1',Hl_v*Ppl']'
   [[PR-(lambdap1+lambdap2),phip';phip,eye(2*Nr*k+Nr^2)],thetap';thetap,...
      blkdiag(lambdap1*eye(Nr*Ns),lambdap2*eye(Nr^2))]>=0
 vec(W)'*vec(W)<=PS
 vec(A)'*vec(A)<=PS
 vec(V)'*vec(V)<=PR

cvx_end

     %% update D 
      if strcmp(cvx_status,'Infeasible')
      break;
   end

cvx_begin sdp  quiet
cvx_solver mosek

variable Dd(k,Nd) complex;
variable betad;
variable lambdadr1 nonnegative
variable lambdadd nonnegative
variable lambdadl nonnegative
variable phid(2*k^2+k*(Nr+Nd),1) complex
variable omegardr1(2*k^2+k*(Nr+Nd),Nr*Ns) complex
variable omegardd(2*k^2+k*(Nr+Nd),Nr*Nd) complex
variable omegardl(2*k^2+k*(Nr+Nd),Nr^2) complex
variable Pdr1(Nr*Ns,2*k^2+k*(Nr+Nd)+1) complex
variable Pdd(Nr*Nd,2*k^2+k*(Nr+Nd)+1) complex
variable Pdl(Nr^2,2*k^2+k*(Nr+Nd)+1) complex
variable thetad(Nr*(Ns+Nd+Nr),2*k^2+k*(Nr+Nd)+1) complex

variable De1(k,Ne) complex
variable De21(Nr,Ne) complex
variable De22(Nr,Ne)  complex
variable De23(Nr,Ne) complex

variable phie1(k^2+k*Ne,1) complex
variable  omegare1er1(k^2+k*Ne,Ne*Nr) complex
variable  Pe1er1(Ne*Nr,k^2+k*Ne+1) complex
variable  thetae1(Ne*Nr,k^2+k*Ne+1) complex
variable betae1
variable lambdae1 nonnegative

variable phie2(Nr^2+3*Nr*Ne,1) complex
variable  omegare2es2(Nr^2+3*Nr*Ne,Ne*Ns)  complex
variable omegare2er2(Nr^2+3*Nr*Ne,Ne*Nr) complex
variable omegare2l(Nr^2+3*Nr*Ne,Nr^2) complex
variable   Pe2es2(Ne*Ns,Nr^2+3*Nr*Ne+1)  complex
variable Pe2er2(Ne*Nr,Nr^2+3*Nr*Ne+1)  complex     
variable Pe2l(Nr^2,Nr^2+3*Nr*Ne+1) complex
variable  thetae2(Ne*Ns+Ne*Nr+Nr^2,Nr^2+3*Nr*Ne+1) complex
variable betae2
variable lambdae21 nonnegative
variable lambdae22 nonnegative
variable lambdae23 nonnegative

variable phie3(a,1) complex
variable  omegare3er1(a,Ne*Nr)  complex
variable omegare3er2(a,Ne*Nr)  complex
variable omegare3es1(a,Ne*Ns)  complex
variable omegare3es2(a,Ne*Ns)  complex
variable omegare3l(a,Nr*Nr)  complex
variable omegare3r1(a,Ns*Nr) complex
variable  Pe3er1(Ne*Nr,a+1)  complex
variable Pe3er2(Ne*Nr,a+1)  complex
variable Pe3es1(Ne*Ns,a+1) complex
variable Pe3es2(Ne*Ns,a+1) complex
variable Pe3l(Nr*Nr,a+1) complex
variable Pe3r1(Ns*Nr,a+1) complex
variable  thetae3(Ne*(2*Nr+2*Ns)+Nr*(Nr+Ns),a+1) complex
variable betae3
variable lambdae31 nonnegative
variable lambdae32 nonnegative
variable lambdae33 nonnegative
variable lambdae34 nonnegative
variable lambdae35 nonnegative
variable lambdae36 nonnegative


maximize(2*k+Nr+2*Ne+2*log_det(Fd)+2*log_det(Fe1)+2*log_det(Fe2)+2*log_det(Fe3)...
    -betad-betae1-betae2-betae3)


subject to
%d
phid==[vec(Fd*(Dd*Hd*G*Hr1*W-eye(k)))',vec(Fd*Dd*Hd*G*Hl*V)',vec(sigr*Fd*Dd*Hd*G)',...
vec(sigd*Fd*Dd)']'
omegardr1==[kron(W.',Fd*Dd*Hd*G)',zeros(k^2+k*(Nr+Nd),Nr*Ns)']'
omegardd==[kron((G*Hr1*W).',Fd*Dd)',kron((G*Hl*V).',Fd*Dd)',kron(G.',sigr*Fd*Dd)',zeros(k*Nd,Nr*Nd)']'
omegardl==[zeros(k^2,Nr^2)',kron(V.',Fd*Dd*Hd*G)',zeros(k*(Nr+Nd),Nr^2)']'
Pdr1==[zeros(Nr*Ns,1),omegardr1']
Pdd==[zeros(Nr*Nd,1),omegardd']
Pdl==[zeros(Nr^2,1),omegardl']
thetad==-[Hrl_v*Pdr1',Hd_v*Pdd',Hl_v*Pdl']'
[[betad-(lambdadr1+lambdadd+lambdadl),phid';phid,eye(2*k^2+k*(Nr+Nd))],thetad';...
    thetad,blkdiag(lambdadr1*eye(Nr*Ns),lambdadd*eye(Nr*Nd),lambdadl*eye(Nr^2))]>=0

%e1
phie1==[vec(Fe1*(De1*Her1*V-eye(k)))',vec(sige*Fe1*De1)']'
omegare1er1==[kron(V.',Fe1*De1)',zeros(k*Ne,Ne*Nr)']'
Pe1er1==[zeros(Ne*Nr,1),omegare1er1']
thetae1==-Her1_v*Pe1er1
[[betae1-lambdae1,phie1';phie1,eye(k^2+k*Ne)],thetae1';thetae1,lambdae1*eye(Ne*Nr)]>=0

%e2
phie2==[vec(Fe2*(De21*Hes2*A*X+De22*Her2*G*Hl*V*X+sigr*De23*Her2*G-eye(Nr)))',...
    vec(sige*Fe2*De21)',vec(sige*Fe2*De22)',vec(sige*Fe2*De23)']'
omegare2es2==[kron((A*X).',Fe2*De21)',zeros(3*Nr*Ne,Ne*Ns)']'
omegare2er2==[kron((G*Hl*V*X).',Fe2*De22)'+kron(G.',sigr*Fe2*De23)',zeros(3*Nr*Ne,Ne*Nr)']'
omegare2l==[kron((V*X).',Fe2*De22*Her2*G)',zeros(3*Nr*Ne,Nr^2)']'
Pe2es2==[zeros(Ne*Ns,1),omegare2es2']
Pe2er2==[zeros(Ne*Ns,1),omegare2er2']
Pe2l==[zeros(Nr^2,1),omegare2l']
thetae2==-[Hes2_v*Pe2es2',Her2_v*Pe2er2',Hl_v*Pe2l']'
[[betae2-(lambdae21+lambdae22+lambdae23),phie2';phie2,eye(Nr^2+3*Nr*Ne)],thetae2';thetae2,...
    blkdiag(lambdae21*eye(Ne*Ns),lambdae22*eye(Nr*Ne),lambdae23*eye(Nr^2))]>=0

%e3
phie3==[vec(Fe31)',vec(Fe32)',vec((sige^-1)*Fe31*Her1*V)',vec((sige^-1)*Fe32*Hes2*A)',...
    vec((sige^-1)*Fe32*Her2*G*Hl*V)',vec((sige^-1)*sigr*Fe32*Her2*G)',vec((sige^-1)*Fe31*Hes1*W)',...
    vec((sige^-1)*Fe32*Her2*G*Hr1*W)']'
omegare3er1==[zeros(4*Ne^2,Ne*Nr)',kron(V.',(sige^-1)*Fe31)',zeros(a-4*Ne^2-2*Ne*k,Ne*Nr)']'
omegare3er2==[zeros(4*Ne^2+4*Ne*k,Ne*Nr)',kron((G*Hl*V).',(sige^-1)*Fe32)',...
    kron(G.',(sige^-1)*sigr*Fe32)',zeros(2*Ne*k,Ne*Nr)',kron((G*Hr1*W).',(sige^-1)*Fe32)']'    
omegare3es1==[zeros(a-4*Ne*k,Ne*Ns)',kron(W.',(sige^-1)*Fe31)',zeros(2*Ne*k,Ne*Ns)']'     
omegare3es2==[zeros(4*Ne^2+2*Ne*k,Ne*Ns)',kron(A.',(sige^-1)*Fe32)',zeros(2*Ne*(3*k+Nr),Ne*Ns)']'      
omegare3l==[zeros(4*Ne^2+4*Ne*k,Nr*Nr)',kron(V.',(sige^-1)*Fe32*Her2*G)',zeros(2*Ne*(Nr+2*k),Nr*Nr)']'    
omegare3r1==[zeros(a-2*Ne*k,Ns*Nr)',kron(W.',(sige^-1)*Fe32*Her2*G)']'       
Pe3er1==[zeros(Ne*Nr,1),omegare3er1']
Pe3er2==[zeros(Ne*Nr,1),omegare3er2']
Pe3es1==[zeros(Ne*Ns,1),omegare3es1']
Pe3es2==[zeros(Ne*Ns,1),omegare3es2']
Pe3l==[zeros(Nr*Nr,1),omegare3l']
Pe3r1==[zeros(Ns*Nr,1),omegare3r1']
thetae3==-[Her1_v*Pe3er1',Her2_v*Pe3er2',Hes1_v*Pe3es1',Hes2_v*Pe3es2',Hl_v*Pe3l',Hrl_v*Pe3r1']'
[[betae3-(lambdae31+lambdae32+lambdae33+lambdae34+lambdae35+lambdae36),phie3';phie3,eye(a)],thetae3';thetae3,...
  blkdiag(lambdae31*eye(Ne*Nr),lambdae32*eye(Ne*Nr),lambdae33*eye(Ne*Ns),lambdae34*eye(Ne*Ns),...
  lambdae35*eye(Nr*Nr),lambdae36*eye(Ns*Nr))]>=0

cvx_end
     

   %% update F

   if strcmp(cvx_status,'Infeasible')
      break;
   end
   
cvx_begin sdp  quiet
cvx_solver mosek

variable Fd(k,k) complex semidefinite  
variable betad
variable lambdadr1 nonnegative
variable lambdadd nonnegative
variable lambdadl nonnegative
variable phid(2*k^2+k*(Nr+Nd),1) complex
variable omegardr1(2*k^2+k*(Nr+Nd),Nr*Ns) complex
variable omegardd(2*k^2+k*(Nr+Nd),Nr*Nd) complex
variable omegardl(2*k^2+k*(Nr+Nd),Nr^2) complex
variable Pdr1(Nr*Ns,2*k^2+k*(Nr+Nd)+1) complex
variable Pdd(Nr*Nd,2*k^2+k*(Nr+Nd)+1) complex
variable Pdl(Nr^2,2*k^2+k*(Nr+Nd)+1) complex
variable thetad(Nr*(Ns+Nd+Nr),2*k^2+k*(Nr+Nd)+1) complex

variable Fe1(k,k)  complex semidefinite
variable Fe2(Nr,Nr) complex semidefinite  
variable Fe31(2*Ne,Ne)  complex
variable Fe32(2*Ne,Ne)  complex
variable Fe3(2*Ne,2*Ne) complex semidefinite  

variable phie1(k^2+k*Ne,1) complex
variable  omegare1er1(k^2+k*Ne,Ne*Nr) complex
variable  Pe1er1(Ne*Nr,k^2+k*Ne+1) complex
variable  thetae1(Ne*Nr,k^2+k*Ne+1) complex
variable betae1
variable lambdae1 nonnegative

variable phie2(Nr^2+3*Nr*Ne,1) complex
variable  omegare2es2(Nr^2+3*Nr*Ne,Ne*Ns)  complex
variable omegare2er2(Nr^2+3*Nr*Ne,Ne*Nr) complex
variable omegare2l(Nr^2+3*Nr*Ne,Nr^2) complex
variable   Pe2es2(Ne*Ns,Nr^2+3*Nr*Ne+1)  complex
variable Pe2er2(Ne*Nr,Nr^2+3*Nr*Ne+1)  complex     
variable Pe2l(Nr^2,Nr^2+3*Nr*Ne+1) complex
variable  thetae2(Ne*Ns+Ne*Nr+Nr^2,Nr^2+3*Nr*Ne+1) complex
variable betae2
variable lambdae21 nonnegative
variable lambdae22 nonnegative
variable lambdae23 nonnegative

variable phie3(a,1) complex 
variable  omegare3er1(a,Ne*Nr)  complex
variable omegare3er2(a,Ne*Nr)  complex
variable omegare3es1(a,Ne*Ns)  complex
variable omegare3es2(a,Ne*Ns)  complex
variable omegare3l(a,Nr*Nr)  complex
variable omegare3r1(a,Ns*Nr) complex
variable  Pe3er1(Ne*Nr,a+1)  complex
variable Pe3er2(Ne*Nr,a+1)  complex
variable Pe3es1(Ne*Ns,a+1) complex
variable Pe3es2(Ne*Ns,a+1) complex
variable Pe3l(Nr*Nr,a+1) complex
variable Pe3r1(Ns*Nr,a+1) complex
variable  thetae3(Ne*(2*Nr+2*Ns)+Nr*(Nr+Ns),a+1) complex
variable betae3
variable lambdae31 nonnegative
variable lambdae32 nonnegative
variable lambdae33 nonnegative
variable lambdae34 nonnegative
variable lambdae35 nonnegative
variable lambdae36 nonnegative


maximize(2*k+Nr+2*Ne+2*log_det(Fd)+2*log_det(Fe1)+2*log_det(Fe2)+2*log_det(Fe3)...
    -betad-betae1-betae2-betae3)


subject to
%d
phid==[vec(Fd*(Dd*Hd*G*Hr1*W-eye(k)))',vec(Fd*Dd*Hd*G*Hl*V)',vec(sigr*Fd*Dd*Hd*G)',...
vec(sigd*Fd*Dd)']'
omegardr1==[kron(W.',Fd*Dd*Hd*G)',zeros(k^2+k*(Nr+Nd),Nr*Ns)']'
omegardd==[kron((G*Hr1*W).',Fd*Dd)',kron((G*Hl*V).',Fd*Dd)',kron(G.',sigr*Fd*Dd)',zeros(k*Nd,Nr*Nd)']'
omegardl==[zeros(k^2,Nr^2)',kron(V.',Fd*Dd*Hd*G)',zeros(k*(Nr+Nd),Nr^2)']'
Pdr1==[zeros(Nr*Ns,1),omegardr1']
Pdd==[zeros(Nr*Nd,1),omegardd']
Pdl==[zeros(Nr^2,1),omegardl']
thetad==-[Hrl_v*Pdr1',Hd_v*Pdd',Hl_v*Pdl']'
[[betad-(lambdadr1+lambdadd+lambdadl),phid';phid,eye(2*k^2+k*(Nr+Nd))],thetad';...
    thetad,blkdiag(lambdadr1*eye(Nr*Ns),lambdadd*eye(Nr*Nd),lambdadl*eye(Nr^2))]>=0

%e1
phie1==[vec(Fe1*(De1*Her1*V-eye(k)))',vec(sige*Fe1*De1)']'
omegare1er1==[kron(V.',Fe1*De1)',zeros(k*Ne,Ne*Nr)']'
Pe1er1==[zeros(Ne*Nr,1),omegare1er1']
thetae1==-Her1_v*Pe1er1
[[betae1-lambdae1,phie1';phie1,eye(k^2+k*Ne)],thetae1';thetae1,lambdae1*eye(Ne*Nr)]>=0

%e2
phie2==[vec(Fe2*(De21*Hes2*A*X+De22*Her2*G*Hl*V*X+sigr*De23*Her2*G-eye(Nr)))',...
    vec(sige*Fe2*De21)',vec(sige*Fe2*De22)',vec(sige*Fe2*De23)']'
omegare2es2==[kron((A*X).',Fe2*De21)',zeros(3*Nr*Ne,Ne*Ns)']'
omegare2er2==[kron((G*Hl*V*X).',Fe2*De22)'+kron(G.',sigr*Fe2*De23)',zeros(3*Nr*Ne,Ne*Nr)']'
omegare2l==[kron((V*X).',Fe2*De22*Her2*G)',zeros(3*Nr*Ne,Nr^2)']'
Pe2es2==[zeros(Ne*Ns,1),omegare2es2']
Pe2er2==[zeros(Ne*Ns,1),omegare2er2']
Pe2l==[zeros(Nr^2,1),omegare2l']
thetae2==-[Hes2_v*Pe2es2',Her2_v*Pe2er2',Hl_v*Pe2l']'
[[betae2-(lambdae21+lambdae22+lambdae23),phie2';phie2,eye(Nr^2+3*Nr*Ne)],thetae2';thetae2,...
    blkdiag(lambdae21*eye(Ne*Ns),lambdae22*eye(Nr*Ne),lambdae23*eye(Nr^2))]>=0

%e3
phie3==[vec(Fe31)',vec(Fe32)',vec((sige^-1)*Fe31*Her1*V)',vec((sige^-1)*Fe32*Hes2*A)',...
    vec((sige^-1)*Fe32*Her2*G*Hl*V)',vec((sige^-1)*sigr*Fe32*Her2*G)',vec((sige^-1)*Fe31*Hes1*W)',...
    vec((sige^-1)*Fe32*Her2*G*Hr1*W)']'
omegare3er1==[zeros(4*Ne^2,Ne*Nr)',kron(V.',(sige^-1)*Fe31)',zeros(a-4*Ne^2-2*Ne*k,Ne*Nr)']'
omegare3er2==[zeros(4*Ne^2+4*Ne*k,Ne*Nr)',kron((G*Hl*V).',(sige^-1)*Fe32)',...
    kron(G.',(sige^-1)*sigr*Fe32)',zeros(2*Ne*k,Ne*Nr)',kron((G*Hr1*W).',(sige^-1)*Fe32)']'    
omegare3es1==[zeros(a-4*Ne*k,Ne*Ns)',kron(W.',(sige^-1)*Fe31)',zeros(2*Ne*k,Ne*Ns)']'     
omegare3es2==[zeros(4*Ne^2+2*Ne*k,Ne*Ns)',kron(A.',(sige^-1)*Fe32)',zeros(2*Ne*(3*k+Nr),Ne*Ns)']'      
omegare3l==[zeros(4*Ne^2+4*Ne*k,Nr*Nr)',kron(V.',(sige^-1)*Fe32*Her2*G)',zeros(2*Ne*(Nr+2*k),Nr*Nr)']'    
omegare3r1==[zeros(a-2*Ne*k,Ns*Nr)',kron(W.',(sige^-1)*Fe32*Her2*G)']'       
Pe3er1==[zeros(Ne*Nr,1),omegare3er1']
Pe3er2==[zeros(Ne*Nr,1),omegare3er2']
Pe3es1==[zeros(Ne*Ns,1),omegare3es1']
Pe3es2==[zeros(Ne*Ns,1),omegare3es2']
Pe3l==[zeros(Nr*Nr,1),omegare3l']
Pe3r1==[zeros(Ns*Nr,1),omegare3r1']
thetae3==-[Her1_v*Pe3er1',Her2_v*Pe3er2',Hes1_v*Pe3es1',Hes2_v*Pe3es2',Hl_v*Pe3l',Hrl_v*Pe3r1']'
[[betae3-(lambdae31+lambdae32+lambdae33+lambdae34+lambdae35+lambdae36),phie3';phie3,eye(a)],thetae3';thetae3,...
  blkdiag(lambdae31*eye(Ne*Nr),lambdae32*eye(Ne*Nr),lambdae33*eye(Ne*Ns),lambdae34*eye(Ne*Ns),...
  lambdae35*eye(Nr*Nr),lambdae36*eye(Ns*Nr))]>=0
Fe3==[Fe31,Fe32]
cvx_end


WorstCaseSecrecyRate(t,index,l)=pos(cvx_optval)/log(2);
l=l+1;
last=this;
this=cvx_optval;
end
% if(~isempty(Y)) 
% WorstCaseSecrecyRate(t,index)=max(Y);
% end
%  if(WorstCaseSecrecyRate(t,index)~=0)
%     count=count+1; 
%  end
% countsum(1,index)=count;
% AverageSecrecyRate(1,index)=sum(WorstCaseSecrecyRate(:,index))/number;
% AverageSecrecyRate(1,index)=sum(WorstCaseSecrecyRate(:,index))/count;
end


t=t+1
end
filename=strcat('collude',num2str(Nd),num2str(Ne),'-',num2str(Sigma_ChannalErr),'.mat');
save(filename);
