     
clc;clear;
load("Pathrecord")
Ns=2;%source antenna
Nr=2;%relay antenna
Nd=2;%destination antenna
Ne=3;%eve antenna
Sigma_ChannalErr=0.075;
X=[eye(k),zeros(k,Nr-k)];



WorstCaseSecrecyRate=zeros(number,index_max,maxy); 
countsum=zeros(1,index_max);
t=1;
while t<=number
    Y=[];%the objective value of each iteration

    

Hr1=Hr1p([1:2],[2*t+1:2*(t+1)]);
Hr1=Hr1(1:Nr,1:Ns);
Hes1=Hes1p([1:3],[2*t+1:2*(t+1)]);
Hes1=Hes1(1:Ne,1:Ns);
Her1=Her1p([1:3],[2*t+1:2*(t+1)]);
Her1=Her1(1:Ne,1:Nr);
Hes2=Hes2p([1:3],[2*t+1:2*(t+1)]);
Hes2=Hes2(1:Ne,1:Ns);
Her2=Her2p([1:3],[2*t+1:2*(t+1)]);
Her2=Her2(1:Ne,1:Nr);
Hd=Hdp([1:3],[2*t+1:2*(t+1)]);
Hd=Hd(1:Nd,1:Nr);
Hl=Hlp([1:2],[2*t+1:2*(t+1)]);
Hl=Hl(1:Nr,1:Nr);

% Hr1=Hr1p([1:Nr],[Ns*t+1:Ns*(t+1)]);
% Hes1=Hes1p([1:Ne],[Ns*t+1:Ns*(t+1)]);
% Her1=Her1p([1:Ne],[Nr*t+1:Nr*(t+1)]);
% Hes2=Hes2p([1:Ne],[Ns*t+1:Ns*(t+1)]);
% Her2=Her2p([1:Ne],[Nr*t+1:Nr*(t+1)]);
% Hd=Hdp([1:Nd],[Nr*t+1:Nr*(t+1)]);
% Hl=Hlp([1:Nr],[Nr*t+1:Nr*(t+1)]);

sigd=sigdp([1:1],[t+1:(t+1)]);
sigr=sigrp([1:1],[t+1:(t+1)]);
sige=sigep([1:1],[t+1:(t+1)]);


Hr1_v=Sigma_ChannalErr*norm(Hr1);
Hl_v=Sigma_ChannalErr*norm(Hl);
Hes1_v=Sigma_ChannalErr*norm(Hes1);
Her1_v=Sigma_ChannalErr*norm(Her1);
Hes2_v=Sigma_ChannalErr*norm(Hes2);
Her2_v=Sigma_ChannalErr*norm(Her2);
Hd_v=Sigma_ChannalErr*norm(Hd);

Fd=eye(k,k);
Fe11=eye(k,k);
Fe12=eye(Ne,Ne);
Fe21=eye(Nr,Nr);
Fe22=eye(Ne,Ne);



cvx_status='';

Dd=(eye(k,Nd)+i*eye(k,Nd))/sqrt(2);
De1=(eye(k,Ne)+i*eye(k,Ne))/sqrt(2);
De21=(eye(Nr,Ne)+i*eye(Nr,Ne))/sqrt(2);
De22=(eye(Nr,Ne)+i*eye(Nr,Ne))/sqrt(2);
De23=(eye(Nr,Ne)+i*eye(Nr,Ne))/sqrt(2);

W=(eye(Nr,k)+i*eye(Nr,k))/sqrt(2);
V=(eye(Nr,k)+i*eye(Nr,k))/sqrt(2);
A=(eye(Nr,k)+i*eye(Nr,k))/sqrt(2);
G=(eye(Nr,Nr)+i*eye(Nr,Nr))/sqrt(2);



for index=1:1:index_max
    PS=10^(((index-1)*interval+DBPtot_min)/10);
    PR=10^(((index-1)*interval+DBPtot_min)/10);
     if strcmp(cvx_status,'Infeasible')
         
W=(eye(Nr,k)+i*eye(Nr,k))/sqrt(2);
V=(eye(Nr,k)+i*eye(Nr,k))/sqrt(2);
A=(eye(Nr,k)+i*eye(Nr,k))/sqrt(2);
G=(eye(Nr,Nr)+i*eye(Nr,Nr))/sqrt(2);

      end

    count=0;
    this=-10000000000;
last=-100000000;
l=1;
while l<=maxy && (abs(this-last)>=0.001)
    
   %% uppdate G
   if strcmp(cvx_status,'Infeasible')
     break;
      end
cvx_begin  sdp  quiet
cvx_solver mosek

%poewr
% variable V(Nr,k) complex
% variable W(Ns,k)  complex
% variable A(Ns,k)  complex

variable G(Nr,Nr) complex

% %D
% variable Dd(k,Nd) complex;
% variable De1(k,Ne) complex;
% variable De21(Nr,Ne) complex;
% variable De22(Nr,Ne) complex;
% variable De23(Nr,Ne) complex;
% 
% %F
% variable Fd(k,k) complex semidefinite 
% variable Fe11(k,k) complex semidefinite
% variable Fe12(Ne,Ne) complex semidefinite
% variable Fe21(Nr,Nr) complex semidefinite
% variable Fe22(Ne,Ne) complex semidefinite



% lambda
variable lambdadr1 nonnegative
variable lambdadd nonnegative
variable lambdadl nonnegative

variable lambdae11 nonnegative

variable lambdae12es1 nonnegative
variable lambdae12er1 nonnegative

variable lambdae21es2 nonnegative
variable lambdae21er2 nonnegative
variable lambdae21l nonnegative

variable lambdae22es2 nonnegative
variable lambdae22er2 nonnegative
variable lambdae22l nonnegative
variable lambdae22r1 nonnegative


%
variable betad;
variable betae11
variable betae12
variable betae21
variable betae22

%d
variable phid(2*k^2+k*(Nr+Nd),1) complex
variable omegardr1(2*k^2+k*(Nr+Nd),Nr*Ns) complex
variable omegardd(2*k^2+k*(Nr+Nd),Nr*Nd) complex
variable omegardl(2*k^2+k*(Nr+Nd),Nr^2) complex
variable Pdr1(Nr*Ns,2*k^2+k*(Nr+Nd)+1) complex
variable Pdd(Nr*Nd,2*k^2+k*(Nr+Nd)+1) complex
variable Pdl(Nr^2,2*k^2+k*(Nr+Nd)+1) complex
variable thetad(Nr*(Ns+Nd+Nr),2*k^2+k*(Nr+Nd)+1) complex

%e11
variable phie11(k^2+k*Ne,1) complex
variable  omegare11er1(k^2+k*Ne,Ne*Nr) complex
variable  Pe11er1(Ne*Nr,k^2+k*Ne+1) complex
variable  thetae11(Ne*Nr,k^2+k*Ne+1) complex

%e12
variable phie12(Ne^2+2*Ne*k,1) complex
variable omegare12es1(Ne^2+2*Ne*k,Ne*Ns)  complex
variable omegare12er1(Ne^2+2*Ne*k,Ne*Nr) complex
variable Pe12es1(Ne*Ns,Ne^2+2*Ne*k+1)  complex
variable Pe12er1(Ne*Nr,Ne^2+2*Ne*k+1)  complex     
variable  thetae12(Ne*(Ns+Nr),Ne^2+2*Ne*k+1) complex

%e21
variable phie21(Nr^2+3*Nr*Ne,1) complex
variable omegare21er2(Nr^2+3*Nr*Ne,Ne*Nr)  complex
variable omegare21es2(Nr^2+3*Nr*Ne,Ne*Ns)  complex
variable omegare21l(Nr^2+3*Nr*Ne,Nr*Nr)  complex
variable Pe21er2(Ne*Nr,Nr^2+3*Nr*Ne+1)  complex
variable Pe21es2(Ne*Ns,Nr^2+3*Nr*Ne+1)  complex
variable Pe21l(Nr*Nr,Nr^2+3*Nr*Ne+1) complex
variable  thetae21(Ne*(Nr+Ns)+Nr*Nr,Nr^2+3*Nr*Ne+1) complex

%e22
variable phie22(3*Ne*k+Ne*(Nr+Ne),1) complex
variable omegare22er2(3*Ne*k+Ne*(Nr+Ne),Ne*Nr)  complex
variable omegare22es2(3*Ne*k+Ne*(Nr+Ne),Ne*Ns)  complex
variable omegare22l(3*Ne*k+Ne*(Nr+Ne),Nr*Nr)  complex
variable omegare22r1(3*Ne*k+Ne*(Nr+Ne),Ns*Nr)  complex
variable Pe22er2(Ne*Nr,3*Ne*k+Ne*(Nr+Ne)+1)  complex
variable Pe22es2(Ne*Ns,3*Ne*k+Ne*(Nr+Ne)+1)  complex
variable Pe22l(Nr*Nr,3*Ne*k+Ne*(Nr+Ne)+1)  complex
variable Pe22r1(Ns*Nr,3*Ne*k+Ne*(Nr+Ne)+1)  complex
variable thetae22(Ne*(Nr+Ns)+Nr*(Nr+Ns),3*Ne*k+Ne*(Nr+Ne)+1) complex

%p
variable phip(2*Nr*k+Nr^2,1) complex
variable omegarpr1(2*Nr*k+Nr^2,Nr*Ns)  complex
variable omegarpl(2*Nr*k+Nr^2,Nr^2) complex
variable Ppr1(Nr*Ns,2*Nr*k+Nr^2+1)  complex
variable Ppl(Nr^2,2*Nr*k+Nr^2+1) complex
variable thetap(Nr*Ns+Nr^2,2*Nr*k+Nr^2+1) complex
variable lambdap1 nonnegative
variable lambdap2 nonnegative


maximize(k+2*log_det(Fd)-betad+min(Ne+k+2*log_det(Fe11)-betae11+2*log_det(Fe12)-betae12,Nr+Ne+2*log_det(Fe21)-betae21+2*log_det(Fe22)-betae22))


subject to
%d
phid==[vec(Fd*(Dd*Hd*G*Hr1*W-eye(k)))',vec(Fd*Dd*Hd*G*Hl*V)',vec(sigr*Fd*Dd*Hd*G)',...
vec(sigd*Fd*Dd)']'
omegardr1==[kron(W.',Fd*Dd*Hd*G)',zeros(k^2+k*(Nr+Nd),Nr*Ns)']'
omegardd==[kron((G*Hr1*W).',Fd*Dd)',kron((G*Hl*V).',Fd*Dd)',kron(G.',sigr*Fd*Dd)',zeros(k*Nd,Nr*Nd)']'
omegardl==[zeros(k^2,Nr^2)',kron(V.',Fd*Dd*Hd*G)',zeros(k*(Nr+Nd),Nr^2)']'
Pdr1==[zeros(Nr*Ns,1),omegardr1']
Pdd==[zeros(Nr*Nd,1),omegardd']
Pdl==[zeros(Nr^2,1),omegardl']
thetad==-[Hr1_v*Pdr1',Hd_v*Pdd',Hl_v*Pdl']'
[[betad-(lambdadr1+lambdadd+lambdadl),phid';phid,eye(2*k^2+k*(Nr+Nd))],thetad';...
    thetad,blkdiag(lambdadr1*eye(Nr*Ns),lambdadd*eye(Nr*Nd),lambdadl*eye(Nr^2))]>=0

%e11
phie11==[vec(Fe11*(De1*Her1*V-eye(k)))',vec(sige*Fe11*De1)']'
omegare11er1==[kron(V.',Fe11*De1)',zeros(k*Ne,Ne*Nr)']'
Pe11er1==[zeros(Ne*Nr,1),omegare11er1']
thetae11==-Her1_v*Pe11er1
[[betae11-lambdae11,phie11';phie11,eye(k^2+k*Ne)],thetae11';thetae11,lambdae11*eye(Ne*Nr)]>=0

%e12
phie12==[vec((sige^-1)*Fe12*Hes1*W)',vec((sige^-1)*Fe12*Her1*V)',vec(Fe12)']'
omegare12es1==[kron(W.',(sige^-1)*Fe12)',zeros(k*Ne+Ne*Ne,Ne*Ns)']'
omegare12er1==[zeros(Ne*k,Ne*Nr)',kron(V.',(sige^-1)*Fe12)',zeros(Ne*Ne,Ne*Nr)']'
Pe12es1==[zeros(Ne*Ns,1),omegare12es1']
Pe12er1==[zeros(Ne*Ns,1),omegare12er1']
thetae12==-[Hes1_v*Pe12es1',Her1_v*Pe12er1']'
[[betae12-(lambdae12es1+lambdae12er1),phie12';phie12,eye(Ne^2+2*Ne*k)],thetae12';thetae12,...
    blkdiag(lambdae12es1*eye(Ne*Ns),lambdae12er1*eye(Nr*Ne))]>=0

%e21
phie21==[vec(Fe21*(De21*Hes2*A*X+De22*Her2*G*Hl*V*X+sigr*De23*Her2*G-eye(Nr)))',vec(sige*Fe21*De21)',vec(sige*Fe21*De22)',vec(sige*Fe21*De23)']'
omegare21er2==[kron((G*Hl*V*X).',Fe21*De22)'+kron(G.',sigr*Fe21*De23)',zeros(3*Ne*Nr,Ne*Nr)']'
omegare21es2==[kron((A*X).',Fe21*De21)',zeros(3*Ne*Nr,Ne*Ns)']'
omegare21l==[kron((V*X).',Fe21*De22*Her2*G)',zeros(3*Ne*Nr,Nr*Nr)']'
Pe21er2==[zeros(Ne*Nr,1),omegare21er2']
Pe21es2==[zeros(Ne*Ns,1),omegare21es2']
Pe21l==[zeros(Nr*Nr,1),omegare21l']
thetae21==-[Her2_v*Pe21er2',Hes2_v*Pe21es2',Hl_v*Pe21l']'
[[betae21-(lambdae21es2+lambdae21er2+lambdae21l),phie21';phie21,eye(Nr^2+3*Nr*Ne)],thetae21';thetae21,...
    blkdiag(lambdae21er2*eye(Ne*Nr),lambdae21es2*eye(Ne*Ns),lambdae21l*eye(Nr*Nr))]>=0

%e22
phie22==[vec((sige^-1)*Fe22*Her2*G*Hr1*W)',vec((sige^-1)*Fe22*Her2*G*Hl*V)',vec((sige^-1)*Fe22*Her2*G)',vec(Fe22)',vec((sige^-1)*sigr*Fe22*Hes2*A)']'
omegare22es2==[zeros(2*Ne*k+Ne*(Nr+Ne),Ne*Ns)',kron(A.',(sige^-1)*sigr*Fe22)']'
omegare22er2==[kron((G*Hr1*W).',(sige^-1)*Fe22)',kron((G*Hl*V).',(sige^-1)*Fe22)',kron(G.',(sige^-1)*Fe22)',zeros(Ne*Ne+Ne*k,Ne*Nr)']'
omegare22l==[zeros(Ne*k,Nr*Nr)',kron(V.',(sige^-1)*Fe22*Her2*G)',zeros(Ne*Nr+Ne*Ne+Ne*k,Nr*Nr)']'
omegare22r1==[kron(W.',(sige^-1)*Fe22*Her2*G)',zeros(2*Ne*k+Ne*(Nr+Ne),Ns*Nr)']'
Pe22es2==[zeros(Ne*Ns,1),omegare22es2']
Pe22er2==[zeros(Ne*Nr,1),omegare22er2']
Pe22l==[zeros(Nr*Nr,1),omegare22l']
Pe22r1==[zeros(Nr*Ns,1),omegare22r1']
thetae22==-[Hes2_v*Pe22es2',Her2_v*Pe22er2',Hl_v*Pe22l',Hr1_v*Pe22r1']'
[[betae22-(lambdae22es2+lambdae22er2+lambdae22l+lambdae22r1),phie22';phie22,eye(3*Ne*k+Ne*(Nr+Ne))],thetae22';thetae22,...
    blkdiag(lambdae22es2*eye(Ne*Ns),lambdae22er2*eye(Nr*Ne),lambdae22l*eye(Nr*Nr),lambdae22r1*eye(Ns*Nr))]>=0

%p
 phip==[vec(G*Hr1*W)',vec(G*Hl*V)',vec(sigr*G)']'
 omegarpr1==[kron(W.',G)',zeros(Nr*k+Nr^2,Nr*Ns)']'
 omegarpl==[zeros(Nr*k,Nr^2)',kron(V.',G)',zeros(Nr^2,Nr^2)']'
 Ppr1==[zeros(Nr*Ns,1),omegarpr1'] 
 Ppl==[zeros(Nr^2,1),omegarpl']  
 thetap==-[Hr1_v*Ppr1',Hl_v*Ppl']'
   [[PR-(lambdap1+lambdap2),phip';phip,eye(2*Nr*k+Nr^2)],thetap';thetap,...
      blkdiag(lambdap1*eye(Nr*Ns),lambdap2*eye(Nr^2))]>=0

 
cvx_end 
%% uppdate W,V,A
   if strcmp(cvx_status,'Infeasible')
     break;
      end
cvx_begin  sdp  quiet
cvx_solver mosek

%poewr

variable V(Nr,k) complex
variable W(Ns,k)  complex
variable A(Ns,k)  complex

% %D
% variable Dd(k,Nd) complex;
% variable De1(k,Ne) complex;
% variable De21(Nr,Ne) complex;
% variable De22(Nr,Ne) complex;
% variable De23(Nr,Ne) complex;
% 
% %F
% variable Fd(k,k) complex semidefinite 
% variable Fe11(k,k) complex semidefinite
% variable Fe12(Ne,Ne) complex semidefinite
% variable Fe21(Nr,Nr) complex semidefinite
% variable Fe22(Ne,Ne) complex semidefinite



% lambda
variable lambdadr1 nonnegative
variable lambdadd nonnegative
variable lambdadl nonnegative

variable lambdae11 nonnegative

variable lambdae12es1 nonnegative
variable lambdae12er1 nonnegative

variable lambdae21es2 nonnegative
variable lambdae21er2 nonnegative
variable lambdae21l nonnegative

variable lambdae22es2 nonnegative
variable lambdae22er2 nonnegative
variable lambdae22l nonnegative
variable lambdae22r1 nonnegative


%
variable betad;
variable betae11
variable betae12
variable betae21
variable betae22

%d
variable phid(2*k^2+k*(Nr+Nd),1) complex
variable omegardr1(2*k^2+k*(Nr+Nd),Nr*Ns) complex
variable omegardd(2*k^2+k*(Nr+Nd),Nr*Nd) complex
variable omegardl(2*k^2+k*(Nr+Nd),Nr^2) complex
variable Pdr1(Nr*Ns,2*k^2+k*(Nr+Nd)+1) complex
variable Pdd(Nr*Nd,2*k^2+k*(Nr+Nd)+1) complex
variable Pdl(Nr^2,2*k^2+k*(Nr+Nd)+1) complex
variable thetad(Nr*(Ns+Nd+Nr),2*k^2+k*(Nr+Nd)+1) complex

%e11
variable phie11(k^2+k*Ne,1) complex
variable  omegare11er1(k^2+k*Ne,Ne*Nr) complex
variable  Pe11er1(Ne*Nr,k^2+k*Ne+1) complex
variable  thetae11(Ne*Nr,k^2+k*Ne+1) complex

%e12
variable phie12(Ne^2+2*Ne*k,1) complex
variable omegare12es1(Ne^2+2*Ne*k,Ne*Ns)  complex
variable omegare12er1(Ne^2+2*Ne*k,Ne*Nr) complex
variable Pe12es1(Ne*Ns,Ne^2+2*Ne*k+1)  complex
variable Pe12er1(Ne*Nr,Ne^2+2*Ne*k+1)  complex     
variable  thetae12(Ne*(Ns+Nr),Ne^2+2*Ne*k+1) complex

%e21
variable phie21(Nr^2+3*Nr*Ne,1) complex
variable omegare21er2(Nr^2+3*Nr*Ne,Ne*Nr)  complex
variable omegare21es2(Nr^2+3*Nr*Ne,Ne*Ns)  complex
variable omegare21l(Nr^2+3*Nr*Ne,Nr*Nr)  complex
variable Pe21er2(Ne*Nr,Nr^2+3*Nr*Ne+1)  complex
variable Pe21es2(Ne*Ns,Nr^2+3*Nr*Ne+1)  complex
variable Pe21l(Nr*Nr,Nr^2+3*Nr*Ne+1) complex
variable  thetae21(Ne*(Nr+Ns)+Nr*Nr,Nr^2+3*Nr*Ne+1) complex

%e22
variable phie22(3*Ne*k+Ne*(Nr+Ne),1) complex
variable omegare22er2(3*Ne*k+Ne*(Nr+Ne),Ne*Nr)  complex
variable omegare22es2(3*Ne*k+Ne*(Nr+Ne),Ne*Ns)  complex
variable omegare22l(3*Ne*k+Ne*(Nr+Ne),Nr*Nr)  complex
variable omegare22r1(3*Ne*k+Ne*(Nr+Ne),Ns*Nr)  complex
variable Pe22er2(Ne*Nr,3*Ne*k+Ne*(Nr+Ne)+1)  complex
variable Pe22es2(Ne*Ns,3*Ne*k+Ne*(Nr+Ne)+1)  complex
variable Pe22l(Nr*Nr,3*Ne*k+Ne*(Nr+Ne)+1)  complex
variable Pe22r1(Ns*Nr,3*Ne*k+Ne*(Nr+Ne)+1)  complex
variable thetae22(Ne*(Nr+Ns)+Nr*(Nr+Ns),3*Ne*k+Ne*(Nr+Ne)+1) complex

%p
variable phip(2*Nr*k+Nr^2,1) complex
variable omegarpr1(2*Nr*k+Nr^2,Nr*Ns)  complex
variable omegarpl(2*Nr*k+Nr^2,Nr^2) complex
variable Ppr1(Nr*Ns,2*Nr*k+Nr^2+1)  complex
variable Ppl(Nr^2,2*Nr*k+Nr^2+1) complex
variable thetap(Nr*Ns+Nr^2,2*Nr*k+Nr^2+1) complex
variable lambdap1 nonnegative
variable lambdap2 nonnegative


maximize(k+2*log_det(Fd)-betad+min(Ne+k+2*log_det(Fe11)-betae11+2*log_det(Fe12)-betae12,Nr+Ne+2*log_det(Fe21)-betae21+2*log_det(Fe22)-betae22))


subject to
%d
phid==[vec(Fd*(Dd*Hd*G*Hr1*W-eye(k)))',vec(Fd*Dd*Hd*G*Hl*V)',vec(sigr*Fd*Dd*Hd*G)',...
vec(sigd*Fd*Dd)']'
omegardr1==[kron(W.',Fd*Dd*Hd*G)',zeros(k^2+k*(Nr+Nd),Nr*Ns)']'
omegardd==[kron((G*Hr1*W).',Fd*Dd)',kron((G*Hl*V).',Fd*Dd)',kron(G.',sigr*Fd*Dd)',zeros(k*Nd,Nr*Nd)']'
omegardl==[zeros(k^2,Nr^2)',kron(V.',Fd*Dd*Hd*G)',zeros(k*(Nr+Nd),Nr^2)']'
Pdr1==[zeros(Nr*Ns,1),omegardr1']
Pdd==[zeros(Nr*Nd,1),omegardd']
Pdl==[zeros(Nr^2,1),omegardl']
thetad==-[Hr1_v*Pdr1',Hd_v*Pdd',Hl_v*Pdl']'
[[betad-(lambdadr1+lambdadd+lambdadl),phid';phid,eye(2*k^2+k*(Nr+Nd))],thetad';...
    thetad,blkdiag(lambdadr1*eye(Nr*Ns),lambdadd*eye(Nr*Nd),lambdadl*eye(Nr^2))]>=0

%e11
phie11==[vec(Fe11*(De1*Her1*V-eye(k)))',vec(sige*Fe11*De1)']'
omegare11er1==[kron(V.',Fe11*De1)',zeros(k*Ne,Ne*Nr)']'
Pe11er1==[zeros(Ne*Nr,1),omegare11er1']
thetae11==-Her1_v*Pe11er1
[[betae11-lambdae11,phie11';phie11,eye(k^2+k*Ne)],thetae11';thetae11,lambdae11*eye(Ne*Nr)]>=0

%e12
phie12==[vec((sige^-1)*Fe12*Hes1*W)',vec((sige^-1)*Fe12*Her1*V)',vec(Fe12)']'
omegare12es1==[kron(W.',(sige^-1)*Fe12)',zeros(k*Ne+Ne*Ne,Ne*Ns)']'
omegare12er1==[zeros(Ne*k,Ne*Nr)',kron(V.',(sige^-1)*Fe12)',zeros(Ne*Ne,Ne*Nr)']'
Pe12es1==[zeros(Ne*Ns,1),omegare12es1']
Pe12er1==[zeros(Ne*Ns,1),omegare12er1']
thetae12==-[Hes1_v*Pe12es1',Her1_v*Pe12er1']'
[[betae12-(lambdae12es1+lambdae12er1),phie12';phie12,eye(Ne^2+2*Ne*k)],thetae12';thetae12,...
    blkdiag(lambdae12es1*eye(Ne*Ns),lambdae12er1*eye(Nr*Ne))]>=0

%e21
phie21==[vec(Fe21*(De21*Hes2*A*X+De22*Her2*G*Hl*V*X+sigr*De23*Her2*G-eye(Nr)))',vec(sige*Fe21*De21)',vec(sige*Fe21*De22)',vec(sige*Fe21*De23)']'
omegare21er2==[kron((G*Hl*V*X).',Fe21*De22)'+kron(G.',sigr*Fe21*De23)',zeros(3*Ne*Nr,Ne*Nr)']'
omegare21es2==[kron((A*X).',Fe21*De21)',zeros(3*Ne*Nr,Ne*Ns)']'
omegare21l==[kron((V*X).',Fe21*De22*Her2*G)',zeros(3*Ne*Nr,Nr*Nr)']'
Pe21er2==[zeros(Ne*Nr,1),omegare21er2']
Pe21es2==[zeros(Ne*Ns,1),omegare21es2']
Pe21l==[zeros(Nr*Nr,1),omegare21l']
thetae21==-[Her2_v*Pe21er2',Hes2_v*Pe21es2',Hl_v*Pe21l']'
[[betae21-(lambdae21es2+lambdae21er2+lambdae21l),phie21';phie21,eye(Nr^2+3*Nr*Ne)],thetae21';thetae21,...
    blkdiag(lambdae21er2*eye(Ne*Nr),lambdae21es2*eye(Ne*Ns),lambdae21l*eye(Nr*Nr))]>=0

%e22
phie22==[vec((sige^-1)*Fe22*Her2*G*Hr1*W)',vec((sige^-1)*Fe22*Her2*G*Hl*V)',vec((sige^-1)*Fe22*Her2*G)',vec(Fe22)',vec((sige^-1)*sigr*Fe22*Hes2*A)']'
omegare22es2==[zeros(2*Ne*k+Ne*(Nr+Ne),Ne*Ns)',kron(A.',(sige^-1)*sigr*Fe22)']'
omegare22er2==[kron((G*Hr1*W).',(sige^-1)*Fe22)',kron((G*Hl*V).',(sige^-1)*Fe22)',kron(G.',(sige^-1)*Fe22)',zeros(Ne*Ne+Ne*k,Ne*Nr)']'
omegare22l==[zeros(Ne*k,Nr*Nr)',kron(V.',(sige^-1)*Fe22*Her2*G)',zeros(Ne*Nr+Ne*Ne+Ne*k,Nr*Nr)']'
omegare22r1==[kron(W.',(sige^-1)*Fe22*Her2*G)',zeros(2*Ne*k+Ne*(Nr+Ne),Ns*Nr)']'
Pe22es2==[zeros(Ne*Ns,1),omegare22es2']
Pe22er2==[zeros(Ne*Nr,1),omegare22er2']
Pe22l==[zeros(Nr*Nr,1),omegare22l']
Pe22r1==[zeros(Nr*Ns,1),omegare22r1']
thetae22==-[Hes2_v*Pe22es2',Her2_v*Pe22er2',Hl_v*Pe22l',Hr1_v*Pe22r1']'
[[betae22-(lambdae22es2+lambdae22er2+lambdae22l+lambdae22r1),phie22';phie22,eye(3*Ne*k+Ne*(Nr+Ne))],thetae22';thetae22,...
    blkdiag(lambdae22es2*eye(Ne*Ns),lambdae22er2*eye(Nr*Ne),lambdae22l*eye(Nr*Nr),lambdae22r1*eye(Ns*Nr))]>=0

%p
 phip==[vec(G*Hr1*W)',vec(G*Hl*V)',vec(sigr*G)']'
 omegarpr1==[kron(W.',G)',zeros(Nr*k+Nr^2,Nr*Ns)']'
 omegarpl==[zeros(Nr*k,Nr^2)',kron(V.',G)',zeros(Nr^2,Nr^2)']'
 Ppr1==[zeros(Nr*Ns,1),omegarpr1'] 
 Ppl==[zeros(Nr^2,1),omegarpl']  
 thetap==-[Hr1_v*Ppr1',Hl_v*Ppl']'
   [[PR-(lambdap1+lambdap2),phip';phip,eye(2*Nr*k+Nr^2)],thetap';thetap,...
      blkdiag(lambdap1*eye(Nr*Ns),lambdap2*eye(Nr^2))]>=0
 vec(W)'*vec(W)<=PS
 vec(A)'*vec(A)<=PS
 vec(V)'*vec(V)<=PR

cvx_end 

    %% step1 update D 
    
     if strcmp(cvx_status,'Infeasible')
      break;
        end

cvx_begin SDP  quiet
cvx_solver mosek

% %poewr
% variable V(Nr,k) complex
% variable W(Ns,k)  complex
% variable A(Ns,k)  complex

%D
variable Dd(k,Nd) complex;
variable De1(k,Ne) complex;
variable De21(Nr,Ne) complex;
variable De22(Nr,Ne) complex;
variable De23(Nr,Ne) complex;
% 
% %F
% variable Fd(k,k) complex semidefinite 
% variable Fe11(k,k) complex semidefinite
% variable Fe12(Ne,Ne) complex semidefinite
% variable Fe21(Nr,Nr) complex semidefinite
% variable Fe22(Ne,Ne) complex semidefinite



% lambda
variable lambdadr1 nonnegative
variable lambdadd nonnegative
variable lambdadl nonnegative

variable lambdae11 nonnegative

variable lambdae12es1 nonnegative
variable lambdae12er1 nonnegative

variable lambdae21es2 nonnegative
variable lambdae21er2 nonnegative
variable lambdae21l nonnegative

variable lambdae22es2 nonnegative
variable lambdae22er2 nonnegative
variable lambdae22l nonnegative
variable lambdae22r1 nonnegative


%
variable betad;
variable betae11
variable betae12
variable betae21
variable betae22

%d
variable phid(2*k^2+k*(Nr+Nd),1) complex
variable omegardr1(2*k^2+k*(Nr+Nd),Nr*Ns) complex
variable omegardd(2*k^2+k*(Nr+Nd),Nr*Nd) complex
variable omegardl(2*k^2+k*(Nr+Nd),Nr^2) complex
variable Pdr1(Nr*Ns,2*k^2+k*(Nr+Nd)+1) complex
variable Pdd(Nr*Nd,2*k^2+k*(Nr+Nd)+1) complex
variable Pdl(Nr^2,2*k^2+k*(Nr+Nd)+1) complex
variable thetad(Nr*(Ns+Nd+Nr),2*k^2+k*(Nr+Nd)+1) complex

%e11
variable phie11(k^2+k*Ne,1) complex
variable  omegare11er1(k^2+k*Ne,Ne*Nr) complex
variable  Pe11er1(Ne*Nr,k^2+k*Ne+1) complex
variable  thetae11(Ne*Nr,k^2+k*Ne+1) complex

%e12
variable phie12(Ne^2+2*Ne*k,1) complex
variable omegare12es1(Ne^2+2*Ne*k,Ne*Ns)  complex
variable omegare12er1(Ne^2+2*Ne*k,Ne*Nr) complex
variable Pe12es1(Ne*Ns,Ne^2+2*Ne*k+1)  complex
variable Pe12er1(Ne*Nr,Ne^2+2*Ne*k+1)  complex     
variable  thetae12(Ne*(Ns+Nr),Ne^2+2*Ne*k+1) complex

%e21
variable phie21(Nr^2+3*Nr*Ne,1) complex
variable omegare21er2(Nr^2+3*Nr*Ne,Ne*Nr)  complex
variable omegare21es2(Nr^2+3*Nr*Ne,Ne*Ns)  complex
variable omegare21l(Nr^2+3*Nr*Ne,Nr*Nr)  complex
variable Pe21er2(Ne*Nr,Nr^2+3*Nr*Ne+1)  complex
variable Pe21es2(Ne*Ns,Nr^2+3*Nr*Ne+1)  complex
variable Pe21l(Nr*Nr,Nr^2+3*Nr*Ne+1) complex
variable  thetae21(Ne*(Nr+Ns)+Nr*Nr,Nr^2+3*Nr*Ne+1) complex

%e22
variable phie22(3*Ne*k+Ne*(Nr+Ne),1) complex
variable omegare22er2(3*Ne*k+Ne*(Nr+Ne),Ne*Nr)  complex
variable omegare22es2(3*Ne*k+Ne*(Nr+Ne),Ne*Ns)  complex
variable omegare22l(3*Ne*k+Ne*(Nr+Ne),Nr*Nr)  complex
variable omegare22r1(3*Ne*k+Ne*(Nr+Ne),Ns*Nr)  complex
variable Pe22er2(Ne*Nr,3*Ne*k+Ne*(Nr+Ne)+1)  complex
variable Pe22es2(Ne*Ns,3*Ne*k+Ne*(Nr+Ne)+1)  complex
variable Pe22l(Nr*Nr,3*Ne*k+Ne*(Nr+Ne)+1)  complex
variable Pe22r1(Ns*Nr,3*Ne*k+Ne*(Nr+Ne)+1)  complex
variable thetae22(Ne*(Nr+Ns)+Nr*(Nr+Ns),3*Ne*k+Ne*(Nr+Ne)+1) complex

%p
variable phip(2*Nr*k+Nr^2,1) complex
variable omegarpr1(2*Nr*k+Nr^2,Nr*Ns)  complex
variable omegarpl(2*Nr*k+Nr^2,Nr^2) complex
variable Ppr1(Nr*Ns,2*Nr*k+Nr^2+1)  complex
variable Ppl(Nr^2,2*Nr*k+Nr^2+1) complex
variable thetap(Nr*Ns+Nr^2,2*Nr*k+Nr^2+1) complex
variable lambdap1 nonnegative
variable lambdap2 nonnegative


maximize(k+2*log_det(Fd)-betad+min(Ne+k+2*log_det(Fe11)-betae11+2*log_det(Fe12)-betae12,Nr+Ne+2*log_det(Fe21)-betae21+2*log_det(Fe22)-betae22))


subject to
%d
phid==[vec(Fd*(Dd*Hd*G*Hr1*W-eye(k)))',vec(Fd*Dd*Hd*G*Hl*V)',vec(sigr*Fd*Dd*Hd*G)',...
vec(sigd*Fd*Dd)']'
omegardr1==[kron(W.',Fd*Dd*Hd*G)',zeros(k^2+k*(Nr+Nd),Nr*Ns)']'
omegardd==[kron((G*Hr1*W).',Fd*Dd)',kron((G*Hl*V).',Fd*Dd)',kron(G.',sigr*Fd*Dd)',zeros(k*Nd,Nr*Nd)']'
omegardl==[zeros(k^2,Nr^2)',kron(V.',Fd*Dd*Hd*G)',zeros(k*(Nr+Nd),Nr^2)']'
Pdr1==[zeros(Nr*Ns,1),omegardr1']
Pdd==[zeros(Nr*Nd,1),omegardd']
Pdl==[zeros(Nr^2,1),omegardl']
thetad==-[Hr1_v*Pdr1',Hd_v*Pdd',Hl_v*Pdl']'
[[betad-(lambdadr1+lambdadd+lambdadl),phid';phid,eye(2*k^2+k*(Nr+Nd))],thetad';...
    thetad,blkdiag(lambdadr1*eye(Nr*Ns),lambdadd*eye(Nr*Nd),lambdadl*eye(Nr^2))]>=0

%e11
phie11==[vec(Fe11*(De1*Her1*V-eye(k)))',vec(sige*Fe11*De1)']'
omegare11er1==[kron(V.',Fe11*De1)',zeros(k*Ne,Ne*Nr)']'
Pe11er1==[zeros(Ne*Nr,1),omegare11er1']
thetae11==-Her1_v*Pe11er1
[[betae11-lambdae11,phie11';phie11,eye(k^2+k*Ne)],thetae11';thetae11,lambdae11*eye(Ne*Nr)]>=0

%e12
phie12==[vec((sige^-1)*Fe12*Hes1*W)',vec((sige^-1)*Fe12*Her1*V)',vec(Fe12)']'
omegare12es1==[kron(W.',(sige^-1)*Fe12)',zeros(k*Ne+Ne*Ne,Ne*Ns)']'
omegare12er1==[zeros(Ne*k,Ne*Nr)',kron(V.',(sige^-1)*Fe12)',zeros(Ne*Ne,Ne*Nr)']'
Pe12es1==[zeros(Ne*Ns,1),omegare12es1']
Pe12er1==[zeros(Ne*Ns,1),omegare12er1']
thetae12==-[Hes1_v*Pe12es1',Her1_v*Pe12er1']'
[[betae12-(lambdae12es1+lambdae12er1),phie12';phie12,eye(Ne^2+2*Ne*k)],thetae12';thetae12,...
    blkdiag(lambdae12es1*eye(Ne*Ns),lambdae12er1*eye(Nr*Ne))]>=0

%e21
phie21==[vec(Fe21*(De21*Hes2*A*X+De22*Her2*G*Hl*V*X+sigr*De23*Her2*G-eye(Nr)))',vec(sige*Fe21*De21)',vec(sige*Fe21*De22)',vec(sige*Fe21*De23)']'
omegare21er2==[kron((G*Hl*V*X).',Fe21*De22)'+kron(G.',sigr*Fe21*De23)',zeros(3*Ne*Nr,Ne*Nr)']'
omegare21es2==[kron((A*X).',Fe21*De21)',zeros(3*Ne*Nr,Ne*Ns)']'
omegare21l==[kron((V*X).',Fe21*De22*Her2*G)',zeros(3*Ne*Nr,Nr*Nr)']'
Pe21er2==[zeros(Ne*Nr,1),omegare21er2']
Pe21es2==[zeros(Ne*Ns,1),omegare21es2']
Pe21l==[zeros(Nr*Nr,1),omegare21l']
thetae21==-[Her2_v*Pe21er2',Hes2_v*Pe21es2',Hl_v*Pe21l']'
[[betae21-(lambdae21es2+lambdae21er2+lambdae21l),phie21';phie21,eye(Nr^2+3*Nr*Ne)],thetae21';thetae21,...
    blkdiag(lambdae21er2*eye(Ne*Nr),lambdae21es2*eye(Ne*Ns),lambdae21l*eye(Nr*Nr))]>=0

%e22
phie22==[vec((sige^-1)*Fe22*Her2*G*Hr1*W)',vec((sige^-1)*Fe22*Her2*G*Hl*V)',vec((sige^-1)*Fe22*Her2*G)',vec(Fe22)',vec((sige^-1)*sigr*Fe22*Hes2*A)']'
omegare22es2==[zeros(2*Ne*k+Ne*(Nr+Ne),Ne*Ns)',kron(A.',(sige^-1)*sigr*Fe22)']'
omegare22er2==[kron((G*Hr1*W).',(sige^-1)*Fe22)',kron((G*Hl*V).',(sige^-1)*Fe22)',kron(G.',(sige^-1)*Fe22)',zeros(Ne*Ne+Ne*k,Ne*Nr)']'
omegare22l==[zeros(Ne*k,Nr*Nr)',kron(V.',(sige^-1)*Fe22*Her2*G)',zeros(Ne*Nr+Ne*Ne+Ne*k,Nr*Nr)']'
omegare22r1==[kron(W.',(sige^-1)*Fe22*Her2*G)',zeros(2*Ne*k+Ne*(Nr+Ne),Ns*Nr)']'
Pe22es2==[zeros(Ne*Ns,1),omegare22es2']
Pe22er2==[zeros(Ne*Nr,1),omegare22er2']
Pe22l==[zeros(Nr*Nr,1),omegare22l']
Pe22r1==[zeros(Nr*Ns,1),omegare22r1']
thetae22==-[Hes2_v*Pe22es2',Her2_v*Pe22er2',Hl_v*Pe22l',Hr1_v*Pe22r1']'
[[betae22-(lambdae22es2+lambdae22er2+lambdae22l+lambdae22r1),phie22';phie22,eye(3*Ne*k+Ne*(Nr+Ne))],thetae22';thetae22,...
    blkdiag(lambdae22es2*eye(Ne*Ns),lambdae22er2*eye(Nr*Ne),lambdae22l*eye(Nr*Nr),lambdae22r1*eye(Ns*Nr))]>=0


cvx_end 
 
%% update F
  if strcmp(cvx_status,'Infeasible')
     break;
      end
   
cvx_begin SDP   quiet
cvx_solver mosek

% %poewr
% variable V(Nr,k) complex
% variable W(Ns,k)  complex
% variable A(Ns,k)  complex
% 
% % %D
% variable Dd(k,Nd) complex;
% variable De1(k,Ne) complex;
% variable De21(Nr,Ne) complex;
% variable De22(Nr,Ne) complex;
% variable De23(Nr,Ne) complex;
% 
% %F
variable Fd(k,k) complex semidefinite 
variable Fe11(k,k) complex semidefinite
variable Fe12(Ne,Ne) complex semidefinite
variable Fe21(Nr,Nr)  complex semidefinite
variable Fe22(Ne,Ne)  complex semidefinite



% lambda
variable lambdadr1 nonnegative
variable lambdadd nonnegative
variable lambdadl nonnegative

variable lambdae11 nonnegative

variable lambdae12es1 nonnegative
variable lambdae12er1 nonnegative

variable lambdae21es2 nonnegative
variable lambdae21er2 nonnegative
variable lambdae21l nonnegative

variable lambdae22es2 nonnegative
variable lambdae22er2 nonnegative
variable lambdae22l nonnegative
variable lambdae22r1 nonnegative


%
variable betad;
variable betae11
variable betae12
variable betae21
variable betae22

%d
variable phid(2*k^2+k*(Nr+Nd),1) complex
variable omegardr1(2*k^2+k*(Nr+Nd),Nr*Ns) complex
variable omegardd(2*k^2+k*(Nr+Nd),Nr*Nd) complex
variable omegardl(2*k^2+k*(Nr+Nd),Nr^2) complex
variable Pdr1(Nr*Ns,2*k^2+k*(Nr+Nd)+1) complex
variable Pdd(Nr*Nd,2*k^2+k*(Nr+Nd)+1) complex
variable Pdl(Nr^2,2*k^2+k*(Nr+Nd)+1) complex
variable thetad(Nr*(Ns+Nd+Nr),2*k^2+k*(Nr+Nd)+1) complex

%e11
variable phie11(k^2+k*Ne,1) complex
variable  omegare11er1(k^2+k*Ne,Ne*Nr) complex
variable  Pe11er1(Ne*Nr,k^2+k*Ne+1) complex
variable  thetae11(Ne*Nr,k^2+k*Ne+1) complex

%e12
variable phie12(Ne^2+2*Ne*k,1) complex
variable omegare12es1(Ne^2+2*Ne*k,Ne*Ns)  complex
variable omegare12er1(Ne^2+2*Ne*k,Ne*Nr) complex
variable Pe12es1(Ne*Ns,Ne^2+2*Ne*k+1)  complex
variable Pe12er1(Ne*Nr,Ne^2+2*Ne*k+1)  complex     
variable  thetae12(Ne*(Ns+Nr),Ne^2+2*Ne*k+1) complex

%e21
variable phie21(Nr^2+3*Nr*Ne,1) complex
variable omegare21er2(Nr^2+3*Nr*Ne,Ne*Nr)  complex
variable omegare21es2(Nr^2+3*Nr*Ne,Ne*Ns)  complex
variable omegare21l(Nr^2+3*Nr*Ne,Nr*Nr)  complex
variable Pe21er2(Ne*Nr,Nr^2+3*Nr*Ne+1)  complex
variable Pe21es2(Ne*Ns,Nr^2+3*Nr*Ne+1)  complex
variable Pe21l(Nr*Nr,Nr^2+3*Nr*Ne+1) complex
variable  thetae21(Ne*(Nr+Ns)+Nr*Nr,Nr^2+3*Nr*Ne+1) complex

%e22
variable phie22(3*Ne*k+Ne*(Nr+Ne),1) complex
variable omegare22er2(3*Ne*k+Ne*(Nr+Ne),Ne*Nr)  complex
variable omegare22es2(3*Ne*k+Ne*(Nr+Ne),Ne*Ns)  complex
variable omegare22l(3*Ne*k+Ne*(Nr+Ne),Nr*Nr)  complex
variable omegare22r1(3*Ne*k+Ne*(Nr+Ne),Ns*Nr)  complex
variable Pe22er2(Ne*Nr,3*Ne*k+Ne*(Nr+Ne)+1)  complex
variable Pe22es2(Ne*Ns,3*Ne*k+Ne*(Nr+Ne)+1)  complex
variable Pe22l(Nr*Nr,3*Ne*k+Ne*(Nr+Ne)+1)  complex
variable Pe22r1(Ns*Nr,3*Ne*k+Ne*(Nr+Ne)+1)  complex
variable thetae22(Ne*(Nr+Ns)+Nr*(Nr+Ns),3*Ne*k+Ne*(Nr+Ne)+1) complex

%p
variable phip(2*Nr*k+Nr^2,1) complex
variable omegarpr1(2*Nr*k+Nr^2,Nr*Ns)  complex
variable omegarpl(2*Nr*k+Nr^2,Nr^2) complex
variable Ppr1(Nr*Ns,2*Nr*k+Nr^2+1)  complex
variable Ppl(Nr^2,2*Nr*k+Nr^2+1) complex
variable thetap(Nr*Ns+Nr^2,2*Nr*k+Nr^2+1) complex
variable lambdap1 nonnegative
variable lambdap2 nonnegative


maximize(k+2*log_det(Fd)-betad+min(Ne+k+2*log_det(Fe11)-betae11+2*log_det(Fe12)-betae12,Nr+Ne+2*log_det(Fe21)-betae21+2*log_det(Fe22)-betae22))


subject to
%d
phid==[vec(Fd*(Dd*Hd*G*Hr1*W-eye(k)))',vec(Fd*Dd*Hd*G*Hl*V)',vec(sigr*Fd*Dd*Hd*G)',...
vec(sigd*Fd*Dd)']'
omegardr1==[kron(W.',Fd*Dd*Hd*G)',zeros(k^2+k*(Nr+Nd),Nr*Ns)']'
omegardd==[kron((G*Hr1*W).',Fd*Dd)',kron((G*Hl*V).',Fd*Dd)',kron(G.',sigr*Fd*Dd)',zeros(k*Nd,Nr*Nd)']'
omegardl==[zeros(k^2,Nr^2)',kron(V.',Fd*Dd*Hd*G)',zeros(k*(Nr+Nd),Nr^2)']'
Pdr1==[zeros(Nr*Ns,1),omegardr1']
Pdd==[zeros(Nr*Nd,1),omegardd']
Pdl==[zeros(Nr^2,1),omegardl']
thetad==-[Hr1_v*Pdr1',Hd_v*Pdd',Hl_v*Pdl']'
[[betad-(lambdadr1+lambdadd+lambdadl),phid';phid,eye(2*k^2+k*(Nr+Nd))],thetad';...
    thetad,blkdiag(lambdadr1*eye(Nr*Ns),lambdadd*eye(Nr*Nd),lambdadl*eye(Nr^2))]>=0

%e11
phie11==[vec(Fe11*(De1*Her1*V-eye(k)))',vec(sige*Fe11*De1)']'
omegare11er1==[kron(V.',Fe11*De1)',zeros(k*Ne,Ne*Nr)']'
Pe11er1==[zeros(Ne*Nr,1),omegare11er1']
thetae11==-Her1_v*Pe11er1
[[betae11-lambdae11,phie11';phie11,eye(k^2+k*Ne)],thetae11';thetae11,lambdae11*eye(Ne*Nr)]>=0

%e12
phie12==[vec((sige^-1)*Fe12*Hes1*W)',vec((sige^-1)*Fe12*Her1*V)',vec(Fe12)']'
omegare12es1==[kron(W.',(sige^-1)*Fe12)',zeros(k*Ne+Ne*Ne,Ne*Ns)']'
omegare12er1==[zeros(Ne*k,Ne*Nr)',kron(V.',(sige^-1)*Fe12)',zeros(Ne*Ne,Ne*Nr)']'
Pe12es1==[zeros(Ne*Ns,1),omegare12es1']
Pe12er1==[zeros(Ne*Ns,1),omegare12er1']
thetae12==-[Hes1_v*Pe12es1',Her1_v*Pe12er1']'
[[betae12-(lambdae12es1+lambdae12er1),phie12';phie12,eye(Ne^2+2*Ne*k)],thetae12';thetae12,...
    blkdiag(lambdae12es1*eye(Ne*Ns),lambdae12er1*eye(Nr*Ne))]>=0

%e21
phie21==[vec(Fe21*(De21*Hes2*A*X+De22*Her2*G*Hl*V*X+sigr*De23*Her2*G-eye(Nr)))',vec(sige*Fe21*De21)',vec(sige*Fe21*De22)',vec(sige*Fe21*De23)']'
omegare21er2==[kron((G*Hl*V*X).',Fe21*De22)'+kron(G.',sigr*Fe21*De23)',zeros(3*Ne*Nr,Ne*Nr)']'
omegare21es2==[kron((A*X).',Fe21*De21)',zeros(3*Ne*Nr,Ne*Ns)']'
omegare21l==[kron((V*X).',Fe21*De22*Her2*G)',zeros(3*Ne*Nr,Nr*Nr)']'
Pe21er2==[zeros(Ne*Nr,1),omegare21er2']
Pe21es2==[zeros(Ne*Ns,1),omegare21es2']
Pe21l==[zeros(Nr*Nr,1),omegare21l']
thetae21==-[Her2_v*Pe21er2',Hes2_v*Pe21es2',Hl_v*Pe21l']'
[[betae21-(lambdae21es2+lambdae21er2+lambdae21l),phie21';phie21,eye(Nr^2+3*Nr*Ne)],thetae21';thetae21,...
    blkdiag(lambdae21er2*eye(Ne*Nr),lambdae21es2*eye(Ne*Ns),lambdae21l*eye(Nr*Nr))]>=0

%e22
phie22==[vec((sige^-1)*Fe22*Her2*G*Hr1*W)',vec((sige^-1)*Fe22*Her2*G*Hl*V)',vec((sige^-1)*Fe22*Her2*G)',vec(Fe22)',vec((sige^-1)*sigr*Fe22*Hes2*A)']'
omegare22es2==[zeros(2*Ne*k+Ne*(Nr+Ne),Ne*Ns)',kron(A.',(sige^-1)*sigr*Fe22)']'
omegare22er2==[kron((G*Hr1*W).',(sige^-1)*Fe22)',kron((G*Hl*V).',(sige^-1)*Fe22)',kron(G.',(sige^-1)*Fe22)',zeros(Ne*Ne+Ne*k,Ne*Nr)']'
omegare22l==[zeros(Ne*k,Nr*Nr)',kron(V.',(sige^-1)*Fe22*Her2*G)',zeros(Ne*Nr+Ne*Ne+Ne*k,Nr*Nr)']'
omegare22r1==[kron(W.',(sige^-1)*Fe22*Her2*G)',zeros(2*Ne*k+Ne*(Nr+Ne),Ns*Nr)']'
Pe22es2==[zeros(Ne*Ns,1),omegare22es2']
Pe22er2==[zeros(Ne*Nr,1),omegare22er2']
Pe22l==[zeros(Nr*Nr,1),omegare22l']
Pe22r1==[zeros(Nr*Ns,1),omegare22r1']
thetae22==-[Hes2_v*Pe22es2',Her2_v*Pe22er2',Hl_v*Pe22l',Hr1_v*Pe22r1']'
[[betae22-(lambdae22es2+lambdae22er2+lambdae22l+lambdae22r1),phie22';phie22,eye(3*Ne*k+Ne*(Nr+Ne))],thetae22';thetae22,...
    blkdiag(lambdae22es2*eye(Ne*Ns),lambdae22er2*eye(Nr*Ne),lambdae22l*eye(Nr*Nr),lambdae22r1*eye(Ns*Nr))]>=0


cvx_end 





WorstCaseSecrecyRate(t,index,l)=pos(cvx_optval)/log(2);
l=l+1;
last=this;
this=cvx_optval;


end
% if(~isempty(Y)) 
% WorstCaseSecrecyRate(t,index)=max(Y);
% end
%     if(WorstCaseSecrecyRate(t,index)~=0)
%        count=count+1;
%     end 
   


% countsum(1,index)=count;
% AverageSecrecyRate(1,index)=sum(WorstCaseSecrecyRate(:,index))/number;
% AAverageSecrecyRate(1,index)=sum(WorstCaseSecrecyRate(:,index))/count;
end

t=t+1

end
filename=strcat('uncollude',num2str(Nd),num2str(Ne),'-',num2str(Sigma_ChannalErr),'.mat');

save(filename)