t=1;
SR=zeros(index_max,1);

while t<number 
    for index=1:1:index_max
        SR(index)=SR(index)+max(WorstCaseSecrecyRate(t,index));
    end
t=t+1;
end

ZZ=SR/number;
